import React from "react";

import "./Calendar.css";
import { Calendar } from "react-calendar";

const CalendarCustom = () => (
  <div className="calendar_section">
    <Calendar />
  </div>
);

export default CalendarCustom;
